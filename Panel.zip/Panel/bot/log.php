<?php
	$pcname = $_POST['pcname'];
	$hwid = $_POST['hwid'];
	$version = $_POST['version'];
	
	$server = mysqli_connect("fdb18.awardspace.net", "2578151_br", "Badywn123", "2578151_br");
	$query = mysqli_query($server, "INSERT INTO `computer_list`(`pcname`, `hwid`, `version`) VALUES ('$pcname','$hwid','$version')");
?>
