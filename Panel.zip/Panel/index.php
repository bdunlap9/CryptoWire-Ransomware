<?php
	include("include/sessions.php");
	session_start();
?>

<html>
	<head>
		<title>CryptoWire v1 | LOGIN</title>
		<link rel="stylesheet" href="css/styles.css">
	</head>
	<body>
		<div style="padding: 20px 15px; text-align: center; font-weight: 500; font-size: 12px; color: #fff; text-transform: uppercase; position: static;">
			<div align="center">
				<div style="background-color:rgba(255,255,255,0.3); color:#FFFFFF; padding:3px; text-align:center;">
					<b>CryptoWire Login | v1</b>
				</div>	
					
				<div style="margin:30px">
					<form align="center" action="" method="post">
						<label>Username:</label><input type="text" name="username" class="box"/><br /><br />
						<label>Password:</label><input type="password" name="password" class="box" /><br/><br />
						<input type="submit" value="Login"/><br />
					</form>
					
					<div style="font-size:11px; color:#cc0000; margin-top:10px">
						<?php echo $error; ?>
					</div>	
				</div>	
			</div>
		</div>
	</body>
</html>
