<?php 
	include("include/sessions.php");
	
	session_start();
	
	if(isset($_POST['submit'])) {
		extract($_POST);
		
		if($old_password="" && $password="" && $confirm_pwd="") {
			$old_pwd = md5(mysqli_real_escape_string($db,$_POST['old_password']));
			$pwd = md5(mysqli_real_escape_string($db,$_POST['password']));
			$c_pwd = md5(mysqli_real_escape_string($db,$_POST['confirm_pwd']));
  
			if($pwd == $c_pwd) {
				if($pwd = $old_pwd) {
					$sql = "SELECT * FROM `users` WHERE `username`='$user_id' AND `password` ='$old_pwd'";
					$db_check = $db->query($sql);
					$count = mysqli_num_rows($db_check);
					
					if($count==1) {
						$fetch = $db->query("UPDATE `users` SET `password` = '$pwd' WHERE `username` = '$user_id'");
						$old_password=''; $password =''; $confirm_pwd = '';
						$msg_sucess = "Your new password update successfully.";
					} else if(($_POST($_POST['submit'])) and $old_pwd == $pwd) {
						$error = "Old password new password same Please try again.";
					} else if(($_POST($_POST['submit'])) and $pwd !== $c_pwd) {
						$error = "New password and confirm password do not matched";
					} else if(count(array_filter($_POST))!=count($_POST)) {
						$error = "Please fill all the fields";
					}
				}
			}
		}
	}
?>

<html>
	<head>
		<title>Cryptowire v1 | CONFIGURE</title>
		<script src="javascript/info.js"></script>
		<link rel="stylesheet" href="css/styles.css">
	</head>
	<body>
		<ul>
			<li><a class="active" href="info.php">List of Infections</a></li>
			<li><a href="settings.php">Configure</a></li>
			<li><a href="index.php">Logout</a></li>
		</ul>
		<h1>CryptoWire Configure</h1>
		<div style="padding: 20px 15px; text-align: center; font-weight: 500; font-size: 12px; color: #fff; text-transform: uppercase;" align="center">
			<div class="test" align="center">	
				<div style="background-color:rgba(255,255,255,0.3); color:#FFFFFF; padding:3px; text-align:center;"><b>Change password</b></div>
					<div style="margin:30px" align="center">
						<form align="center" method="post" autocomplete="off" id="password_form">
							<label>Old password:</label><input type="text" name="old_password"/><br /><br />
							<label>New password:</label><input type="password" name="password"/><br/><br />
							<label>Confirm password:</label><input type="password" name="confirm_pwd"/><br/><br />
							<input type="submit" value="SAVE PASSWORD"/><br />
	
							<div class="<?=(@$msg_sucess=="") ? 'error' : 'green' ; ?>" id="logerror">
								<?php echo @$error; ?>
								<?php echo @$msg_sucess; ?>
							</div>
						</form>
					<div style="font-size:11px; color:#cc0000; margin-top:10px">
						<?php echo $error; ?>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>
